create function update_avg_mountain_height() returns trigger
    language plpgsql
as
$$
BEGIN
    BEGIN
        UPDATE Countries SET average_mountain_height = (
            SELECT AVG(height) FROM Mountains WHERE country_id = NEW.country_id
        ) WHERE country_id = NEW.country_id;
        RETURN NEW;
    EXCEPTION
        WHEN foreign_key_violation THEN
            RAISE EXCEPTION 'Ошибка: Ключ (country_id)=(%) отсутствует в таблице "countries".', NEW.country_id;
    END;
END;
$$;

alter function update_avg_mountain_height() owner to s368051;

