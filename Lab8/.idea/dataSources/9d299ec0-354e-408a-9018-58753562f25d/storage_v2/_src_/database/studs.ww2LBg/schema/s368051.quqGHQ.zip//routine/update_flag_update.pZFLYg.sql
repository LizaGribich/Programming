create function update_flag_update() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Обновление флага изменения в таблице flag_table при операции UPDATE
    UPDATE flag_table SET is_changed = TRUE WHERE id = 1;
    RETURN NEW;
END;
$$;

alter function update_flag_update() owner to s368051;

