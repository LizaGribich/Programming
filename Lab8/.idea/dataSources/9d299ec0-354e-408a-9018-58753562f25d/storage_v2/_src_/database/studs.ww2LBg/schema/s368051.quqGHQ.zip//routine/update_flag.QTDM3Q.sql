create function update_flag() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Обновление флага изменения в таблице flag_table
    UPDATE flag_table SET is_changed = TRUE WHERE id = 1;
    RETURN NEW;
END;
$$;

alter function update_flag() owner to s368051;

