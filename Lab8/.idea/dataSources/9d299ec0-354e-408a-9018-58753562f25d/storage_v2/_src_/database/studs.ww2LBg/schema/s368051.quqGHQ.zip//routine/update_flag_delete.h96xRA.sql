create function update_flag_delete() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Обновление флага изменения в таблице flag_table при операции DELETE
    UPDATE flag_table SET is_changed = TRUE WHERE id = 1;
    RETURN OLD;
END;
$$;

alter function update_flag_delete() owner to s368051;

